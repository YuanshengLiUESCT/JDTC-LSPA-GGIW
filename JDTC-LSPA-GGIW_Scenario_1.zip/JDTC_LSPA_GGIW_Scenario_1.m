

clear all;
close all;
MC=2;
motob=MC;
motono=MC;
v1=0;




time=80; %time
%MPCLASS
x_ospam=zeros(1,time);
X_ospam=zeros(1,time);
r_ospam=zeros(1,time);



 pp=2;
cc3=2*10^4;

T = 1;% time interval 
TS=10;%Start time of birth target
TE=30;%End time of birth target
TS1=50;%Start time of birth target
TE1=70;%End time of birth target
sigma_v =10;
Q= (sigma_v)^2* diag([1,1]); %process noise covariance
G=[T^2/2,0;T,0;0,T^2/2;0,T];
d=2; %dimension
WP2={};
for moto=1:MC
    no=0;

re=0;


T = 1;

%CV MODEL
F_CV = [1 T 0 0;
        0 1 0 0;
        0 0 1 T;
        0 0 0 1];
q_CV =0.016;
Q_CV = q_CV * [T^3/3 T^2/2 0     0;
               T^2/2 T     0     0;
               0     0     T^3/3 T^2/2;
               0     0     T^2/2 T];


%  Initial State state
      
x1 =[];      
x1(:,1) = [1000 8 1000 -8]';
x2=[];
x2(:,1) = [0 8 0 8]';
x3(:,1) = [2200 2 2200 -2]';
x4(:,TS) = [-550 -2 -850 2]';
x5(:,TS1) = [-550 -2 -850 2]';


wt=[];
    FF={};
    QQ={};
for i = 2:time
   x1(:,i) = F_CV * x1(:,i-1);
     x2(:,i) = F_CV * x2(:,i-1);
      x3(:,i) = F_CV * x3(:,i-1);
     if i>TS && i<=TE
       x4(:,i) = F_CV * x4(:,i-1);
     end
       if i>TS1 && i<=TE1
        x5(:,i) = F_CV * x5(:,i-1);
       end
    wt(1:i)=0;                    
    FF{1,i}=F_CV;
    QQ{1,i}=Q_CV;
end 
clutter_exp_num=60; %Clutter average
clutter_inten =2.5e-6;      
Volume_zone = 2000 * 2000; 
Ps=0.9;%survival probability 
Pd = 0.99;%detection probability 
Pb=0.01;
H = [1 0 0 0;
     0 0 1 0];
 %measurement rate

r1=19; 
r2=19;
r3=19;
r4=19;
r5=19;
 yitar=1.25;
 
 %***************************************************************************************************************************
 
 
 
 
 
 
 
 
 
 
                                                         XX={};
                                                        ZPC1=diag([70^2 40^2]);  
                                                         ZPC2=diag([10^2 7.5^2]);  %size
                                                         ZK=cell(1,time);
                                                         detac=10;
                                                            ZPC={ZPC1,ZPC2};
  for k=1:time
                                                             
                                                             
                                                          
           %Extended matrix definition                                                  
if k>=TS && k<=TE 

s=atan(x1(4,k)/x1(2,k));

E1=[cos(s),-sin(s);sin(s),cos(s)];
 X1=(E1^(-1))*ZPC1*(E1^(-1))';

 s=atan(x2(4,k)/x2(2,k));
 E2=[cos(s),-sin(s);sin(s),cos(s)];
  X2=(E2^(-1))*ZPC2*(E2^(-1))';
%   E={E1,E2};
%   X={X1,X2};
s=atan(x3(4,k)/x3(2,k));
 %s=0;
 E3=[cos(s),-sin(s);sin(s),cos(s)];
  X3=(E3^(-1))*ZPC1*(E3^(-1))';
  
  
  s=atan(x4(4,k)/x4(2,k));
 %s=0;
 E4=[cos(s),-sin(s);sin(s),cos(s)];
  X4=(E4^(-1))*ZPC1*(E4^(-1))';
   else
          s=atan(x1(4,k)/x1(2,k));
% s=0;
E1=[cos(s),-sin(s);sin(s),cos(s)];
 X1=(E1^(-1))*ZPC1*(E1^(-1))'; 

 s=atan(x2(4,k)/x2(2,k));
 E2=[cos(s),-sin(s);sin(s),cos(s)];
  X2=(E2^(-1))*ZPC2*(E2^(-1))';
  s=atan(x3(4,k)/x3(2,k));
 %s=0;
 E3=[cos(s),-sin(s);sin(s),cos(s)];
  X3=(E3^(-1))*ZPC1*(E3^(-1))';
end
      if k>=TS1 && k<=TE1
  

s=atan(x1(4,k)/x1(2,k));
% s=0;
E1=[cos(s),-sin(s);sin(s),cos(s)];
 X1=(E1^(-1))*ZPC1*(E1^(-1))'; 

 s=atan(x2(4,k)/x2(2,k));
 E2=[cos(s),-sin(s);sin(s),cos(s)];
  X2=(E2^(-1))*ZPC2*(E2^(-1))';

s=atan(x3(4,k)/x3(2,k));
 %s=0;
 E3=[cos(s),-sin(s);sin(s),cos(s)];
  X3=(E3^(-1))*ZPC1*(E3^(-1))';
  
  s=atan(x5(4,k)/x5(2,k));
 %s=0;
 E5=[cos(s),-sin(s);sin(s),cos(s)];
  X5=(E5^(-1))*ZPC2*(E5^(-1))';
  
    else
          s=atan(x1(4,k)/x1(2,k));
% s=0;
E1=[cos(s),-sin(s);sin(s),cos(s)];
 X1=(E1^(-1))*ZPC1*(E1^(-1))'; 

 s=atan(x2(4,k)/x2(2,k));
 E2=[cos(s),-sin(s);sin(s),cos(s)];
  X2=(E2^(-1))*ZPC2*(E2^(-1))';
 
  s=atan(x3(4,k)/x3(2,k));
 %s=0;
 E3=[cos(s),-sin(s);sin(s),cos(s)];
  X3=(E3^(-1))*ZPC1*(E3^(-1))';
  end
      
  
  
    
  
R1 = diag([1 1]');
lamuda=0.25;
RC1=lamuda*X1+R1;
RC2=lamuda*X2+R1;
RC3=lamuda*X3+R1;
if k>=TS && k<=TE 
 RC4=lamuda*X4+R1;
end                                                      
if k>=TS1 && k<=TE1
RC5=lamuda*X5+R1;
end
                                                  
                                                             
    
                                                         
 E=[cos(s),-sin(s);sin(s),cos(s)];                                     %Measurement generated
                                                      %
                                                              targetnum1=poissrnd(r1);
                                                              
                                                               targetnum2=poissrnd(r2);
                                                              
                                                               targetnum3=poissrnd(r3);
                                                               
                                                                targetnum4=poissrnd(r4);
                                                                targetnum5=poissrnd(r5);
                                                                
                                                               
                                                                
                                                                
                                                                
                                                                
                                                                target33(1,k)=targetnum1;
                                                                target33(2,k)=targetnum2;
                                                                 target33(3,k)=targetnum3;
                                                                 target33(4,k)=targetnum4;
                                                                 target33(5,k)=targetnum5;
                                                              clutternum = poissrnd(clutter_exp_num);
                                                                ZD_noise=[(1000-2000*rand(2,clutternum))];
                                                               if k>=TS && k<=TE    
                                                              
                                                                    targetnum=targetnum1+targetnum2+targetnum3+targetnum4;%
                                                              
                                                              
                                                                
                                                           Znum=targetnum+clutternum;  
                                                       
                                                         Z=zeros(2,targetnum);
                                                         
                                                         for i=1:targetnum1
                                                         Z(:,i)=H*x1(:,k)+ sqrtm(RC1)*randn(2,1);
                                                         end
                                         
                                                           for i=(targetnum1+1):(targetnum1+targetnum2)
                                                         Z(:,i)=H*x2(:,k)+sqrtm(RC2)*randn(2,1); 
                                                           end
                                                             
                                                            for i=(targetnum1+targetnum2+1):(targetnum1+targetnum2+targetnum3)
                                                         Z(:,i)=H*x3(:,k)+sqrtm(RC3)*randn(2,1); 
                                                            end   
                                                             for i=(targetnum1+targetnum2+targetnum3+1):(targetnum)
                                                         Z(:,i)=H*x4(:,k)+sqrtm(RC4)*randn(2,1); 
                                                            end  
                                                           
                                                                else if k>=TS1 && k<=TE1
                                                                    
                                                                       targetnum=targetnum1+targetnum2+targetnum3+targetnum5;%
                                                              
                                                              
                                                               
                                                           Znum=targetnum+clutternum;  
                                                       
                                                         Z=zeros(2,targetnum);
                                                         %R=100*[1,0;0,1];
                                                         for i=1:targetnum1
                                                         Z(:,i)=H*x1(:,k)+ sqrtm(RC1)*randn(2,1);
                                                         end
                                         
                                                           for i=(targetnum1+1):(targetnum1+targetnum2)
                                                         Z(:,i)=H*x2(:,k)+sqrtm(RC2)*randn(2,1); 
                                                           end
                                                             
                                                            for i=(targetnum1+targetnum2+1):(targetnum1+targetnum2+targetnum3)
                                                         Z(:,i)=H*x3(:,k)+sqrtm(RC3)*randn(2,1); 
                                                            end 
                                                            
                                                            
                                                             for i=(targetnum1+targetnum2+targetnum3+1):(targetnum)
                                                         Z(:,i)=H*x5(:,k)+sqrtm(RC5)*randn(2,1); 
                                                            end 
                                                                    else
                                                             targetnum=targetnum1+targetnum2+targetnum3;
                                                             Z=zeros(2,targetnum);
                                                             for i=1:targetnum1
                                                         Z(:,i)=H*x1(:,k)+ sqrtm(RC1)*randn(2,1);
                                                         end
                                         
                                                           for i=(targetnum1+1):(targetnum1+targetnum2)
                                                         Z(:,i)=H*x2(:,k)+sqrtm(RC2)*randn(2,1); 
                                                           end
                                                            for i=(targetnum1+targetnum2+1):(targetnum)
                                                         Z(:,i)=H*x3(:,k)+sqrtm(RC3)*randn(2,1); 
                                                           end
                                                            
                                                                    end
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                            
                                                                end
                                                             
                                                        
                                                           ZK{1,k}=cat(2,Z,ZD_noise);  
                                                        
                                                         
                                                        %
%                                                         
%                                                                                                                       

                                                           
                                                           end
                                                           
                                                         JBK=3; %PEO for the initial time
                                                             c_num=2;
%                                                          
                                                         
                                                 deta=1;      
                                                x_state=[x1(:,1),x2(:,1),x3(:,1)]; 
                                                cum=2; 
                                               
                                                                 Birth={};
                                                               for j=1:JBK
                                                                    i=0;
                                                                     birth={};
                                                                  for c=1:c_num
                                                                       i=i+1;
                                                                  
                                                                
                                                                  
                                                                  birth{1,i}=1;
                                                          birth{2,i}=1; 
                                                          birth{3,i}=x_state(:,j)+G*sqrtm(Q)*randn(2,1);                                                      
                                                          birth{4,i} = diag([10^2 10^2 10^2 10^2]');
                                                         birth{5,i}=10; %v
                                                         birth{6,i}=diag([1 1]');%V
                                                          birth{7,i}=20;%gamma_alfa
                                                          birth{8,i}=1;%gamma_beita
                                                          birth{9,i}=c;%c
                                                           birth{10,i}=1/c_num;%pr
                                                         
                                                            birth1{1,i}=0;%r
                                                          birth1{2,i}=0.0001; %f~
                                                        end
                                                        
                                                        
                                                         
                                                                 
                                                                    Birth{1,j}=birth;
                                                                    Birth{2,j}=birth1;
                                                                  
                                                                
                                                               end

                                                    
                                    
                                                        
                                                

   BP_update={};

BP_pre={}; 
for k=1:time
    K=JBK+size([BP_update],2);
 Target_num = K; 
if k==1
  Birth1=Birth;
  for i=1:size([Birth],2)
      for j=1:c_num
      Birth1{1,i}{2,j}=Birth{1,i}{2,1}*0.5;
      Birth1{2,i}{2,j}=0; 
      end
  end
  
  BP_pre=Birth1;
  birth{3,1}=x4(:,TS)+G*sqrtm(Q)*randn(2,1);
  birth{3,2}=x4(:,TS)+G*sqrtm(Q)*randn(2,1);
  Birth5{1,1}=birth;
       Birth5{1,1}{2,1}=Birth5{1,1}{2,1}*0.5;   
       Birth5{1,1}{2,2}=Birth5{1,1}{2,2}*0.5;   
        Birth5{2,1}{1,1}=0;
      Birth5{2,1}{2,1}=0;
      
      
      
      BP_pre=Birth1;
  birth{3,1}=x5(:,TS1)+G*sqrtm(Q)*randn(2,1);
  birth{3,2}=x5(:,TS1)+G*sqrtm(Q)*randn(2,1);
  Birth6{1,1}=birth;
       Birth6{1,1}{2,1}=Birth6{1,1}{2,1}*0.5;   
       Birth6{1,1}{2,2}=Birth6{1,1}{2,2}*0.5;   
        Birth6{2,1}{1,1}=0;
      Birth6{2,1}{2,1}=0;

BP_pre=[BP_pre];
else

    deta=1;
          s=wt(1,k);
         M=[cos(s),-sin(s);sin(s),cos(s)];
    
    
BP_pre={};

 for i=1:size(BP_update,2)
     aa=1;
     for j=1:size(BP_update{1,i},2)
        BP_pre{1,i}{1,aa}=1;
      BP_pre{1,i}{2,aa}=(BP_update{1,i}{2,j})*Ps;
      BP_pre{1,i}{3,aa}=FF{1,k}*BP_update{1,i}{3,j};
      BP_pre{1,i}{4,aa}=FF{1,k}*BP_update{1,i}{4,j}*( FF{1,k})'+QQ{1,k};
       lamda= BP_update{1,i}{5,j}-2*d-2;  
      BP_pre{1,i}{5,aa}=((2*deta*(lamda-1)*(lamda-2))/((lamda^2)*(lamda+1)^(-1)*(lamda+deta)))+2*d+4;  
      BP_pre{1,i}{6,aa}=((BP_pre{1,i}{5,aa}-2*d-2)*(M*BP_update{1,i}{6,j}*M.'))*deta/lamda; 
      BP_pre{1,i}{7,aa}=BP_update{1,i}{7,j}/yitar;
      BP_pre{1,i}{8,aa}=BP_update{1,i}{8,j}/yitar;
      BP_pre{1,i}{9,aa}=BP_update{1,i}{9,j};
      BP_pre{1,i}{10,aa}=BP_update{1,i}{10,j};
    
      BP_pre{2,i}{2,1}=1-BP_pre{1,i}{2,1};
      BP_pre{2,i}{1,1}=0; 
      aa=aa+1;
     end
 end
 


if k==TS || size(BP_pre,2)<2
BP_pre=[BP_pre,Birth5];
else if  k==TS1 || size(BP_pre,2)<2 
   BP_pre=[BP_pre,Birth6];
end

end
BP_pre1{1,k}=BP_pre;
end


 if k>=TS && k<=TE
      xk={x1(:,k),x2(:,k),x3(:,k),x4(:,k)};
 else if k>=TS1 && k<=TE1
      xk={x1(:,k),x2(:,k),x3(:,k),x5(:,k)};
     else
     xk={x1(:,k),x2(:,k),x3(:,k)};
     end
 end

 
  WP={};
 WP=partition(ZK{1,k},xk);  
  WP(cellfun(@isempty,WP))=[];
 WP{1,size(WP,2)+1}=[]; 
 WPW{1,k}=WP;

BP_update={};
beita={};

for i=1:size(BP_pre,2)  
     for a=1:size(WP,2)
    for j=1:size(BP_pre{1,i},2)   
       
   
        
                  s=atan(BP_pre{1,i}{3,j}(4,:)/BP_pre{1,i}{3,j}(2,:));
                 E=[cos(s),-sin(s);sin(s),cos(s)];
                
              if BP_pre{1,i}{2,j}==0.5
                  
                   XE2=(E^(-1))*ZPC{1,1}*((E^(-1))');
                      
                    XE=XE2;
                  
                   XE=50^(2)*diag([1,1]);
                else
                XE=BP_pre{1,i}{6,j}/(BP_pre{1,i}{5,j}-2*d-2);
              end
                try
                 
              
 B=chol(lamuda*XE+R1)'*chol(XE)^(-1)';
                catch
                 
                XE=50^(2)*diag([1,1]);
                
                B=chol(lamuda*XE+R1)'*chol(XE)^(-1)';
             end
B=chol(lamuda*XE+R1)'*chol(XE)^(-1)';
 BXB=lamuda*XE+R1;
                       
                   

mn_max=30;

  
  if size(WP{1,a},2)~=0
        Z=0;
                       for s=1:size(WP{1,a},2)
                       Z=Z+((WP{1,a}(:,s)-mean(WP{1,a},2))*((WP{1,a}(:,s)-mean(WP{1,a},2)))');
                       end  
        
                  S=H* BP_pre{1,i}{4,j}*H'+BXB/size(WP{1,a},2);
                       K=BP_pre{1,i}{4,j}*H'*S^(-1);
                       e=mean(WP{1,a},2)-H*BP_pre{1,i}{3,j};
                       N=(e*e')*S^(-1)*XE;
                        P=BP_pre{1,i}{4,j}-K*H*BP_pre{1,i}{4,j};
                          
                       v=BP_pre{1,i}{5,j}+size(WP{1,a},2)+detac;
                     
                       V=BP_pre{1,i}{6,j}+N+(B)^(-1)*Z*(B^(-1))'+detac*(E)^(-1)*ZPC{1,BP_pre{1,i}{9,j}}*((E)^(-1))';
   
        
       hua_num=size( WP{1,a},2);
        bQ=(1/clutter_inten)^(hua_num)*factorial(hua_num)*Pd* BP_pre{1,i}{2,j}*BP_pre{1,i}{10,j};
   
      w1=(2^(-(hua_num+detac)*d/2))*((pi)^(-hua_num*d/2))*2^((hua_num+detac)/2)*(hua_num^(-d/2))*((det(B*B'))^(-(hua_num-1)/2))*((det(S*(XE^(-1))))^(-1/2))*((det(ZPC{1,BP_pre{1,i}{9,j}}))^((detac-d-1)/2))*(detac^(detac/2)); 
w2=(det(BP_pre{1,i}{6,j}))^((BP_pre{1,i}{5,j}-d-1)/2)/(det(V)^((v-d-1)/2)); 
w3=(gamma((v-d-1)/2)*gamma((v-d-2)/2))/(gamma(((BP_pre{1,i}{5,j}-d-1)/2))*gamma(((BP_pre{1,i}{5,j}-d-2)/2))*(pi^(d*(d-1)/4)*gamma(detac/2)*gamma((detac-1)/2)));
                     
        bL=w1*w2*w3;
        bG= (gamma(BP_pre{1,i}{7,j}+hua_num)*(BP_pre{1,i}{8,j})^(BP_pre{1,i}{7,j}))/(gamma(BP_pre{1,i}{7,j})*(1+BP_pre{1,i}{8,j})^(BP_pre{1,i}{7,j}+hua_num)*factorial(hua_num)+eps);  
      

      
beita{1,i}{1,a}(1,j)=bQ*bL*bG; 







 
  else
beita{1,i}{1,a}(1,j)=0;      
if  k>=TE1+1 ||  (k>=TE+1 && k<TS1)
  beita{1,i}{1,a}(1,j)=(1-Pd)*sum([BP_pre{1,i}{2,:}])+BP_pre{2,i}{2,1};
end
  end

  end
beitaa{1,i}{1,a}=sum(beita{1,i}{1,a});
    end
end
 beita10{1,k}=beitaa;


vv={};
l=1;
 while(l~=2)
     
for i=1:size(BP_pre,2) 
for a=1:size(WP,2)
     xi=0;
 if l==1
              for kk=1:size(BP_pre,2)
                  if(kk~=i)
                      summ=0;
                      for ss=1:size(beitaa{1,kk},2)
                          if ss~=a
                      summ=summ+cell2mat(beitaa{1,kk}(1,ss));
                          end
                      end
                      xi=xi+(cell2mat(beitaa{1,kk}(1,a))/summ);

        
          end
              end 
              vv{1,l}(i,a)= abs(1/(1+xi));
              
              
 else
     beita1={};
      
         for kk=1:size(BP_pre,2)
                  if(kk~=i)
                      last=size(beitaa{1,kk},2);
                      for aa=1:(last-1)   
                      beita1{1,kk}(1,aa)=cell2mat(beitaa{1,kk}(1,aa))*((vv{1,l-1}(i,aa))^(size(WP(1,aa),2)));
                      end
                      beita2=(cell2mat(beitaa{1,kk}(1,a))*(vv{1,l-1}(i,a))^(size(WP(1,a),2)));
                      xi=xi+((cell2mat(beitaa{1,kk}(1,a))*(vv{1,l-1}(i,a))^(size(WP(1,a),2)-1))/(cell2mat(beitaa{1,kk}(1,last))+sum(beita1{1,kk})-beita2));
        
          end
              end 
     
     vv{1,l}(i,a)= 1/(1+xi);
     
 end
    
    
    
    
    
    

end
 vv{1,l}(i,a)=1; 

end
l=l+1;
 end
 
 
 
 
yita=[];
 for i=1:size(BP_pre,2) 
     aa=1;
      for j=1:size(BP_pre{1,i},2)
          for a=1:size(WP,2)
                  s=atan(BP_pre{1,i}{3,j}(4,:)/BP_pre{1,i}{3,j}(2,:));
                 E=[cos(s),-sin(s);sin(s),cos(s)];
                
              if k==1 || k==TS ||  k==TS1
                  
                   XE2=(E^(-1))*ZPC{1,1}*((E^(-1))');
                      
                    XE=XE2;
                  
                else
                XE=BP_pre{1,i}{6,j}/(BP_pre{1,i}{5,j}-2*d-2);
              end
                try
                 
              
 B=chol(lamuda*XE+R1)'*chol(XE)^(-1)';
                catch
                 
                XE=50^(2)*diag([1,1]);
               
                B=chol(lamuda*XE+R1)'*chol(XE)^(-1)';
             end
B=chol(lamuda*XE+R1)'*chol(XE)^(-1)';
 BXB=lamuda*XE+R1;
                               


 yita(i,a)= (vv{1,l-1}(i,a))^(size(WP{1,a},2));
if size(WP{1,a},2)~=0 
        Z=0;
                       for s=1:size(WP{1,a},2)
                       Z=Z+((WP{1,a}(:,s)-mean(WP{1,a},2))*((WP{1,a}(:,s)-mean(WP{1,a},2)))');
                       end  
        
                  S=H* BP_pre{1,i}{4,j}*H'+BXB/size(WP{1,a},2);
                       K=BP_pre{1,i}{4,j}*H'*S^(-1);
                       e=mean(WP{1,a},2)-H*BP_pre{1,i}{3,j};
                       N=(e*e')*S^(-1)*XE;
                        P=BP_pre{1,i}{4,j}-K*H*BP_pre{1,i}{4,j};
                          
                         v=BP_pre{1,i}{5,j}+size(WP{1,a},2)+detac;
                       V=BP_pre{1,i}{6,j}+N+(B)^(-1)*Z*(B^(-1))'+detac*(E)^(-1)*ZPC{1,BP_pre{1,i}{9,j}}*((E)^(-1))';
                       
                        
        hua_num=size( WP{1,a},2);
        bQ=(1/clutter_inten)^(hua_num)*factorial(hua_num)*Pd* BP_pre{1,i}{2,j}*BP_pre{1,i}{10,j};
      
      w1=(2^(-(hua_num+detac)*d/2))*((pi)^(-hua_num*d/2))*2^((hua_num+detac)/2)*(hua_num^(-d/2))*((det(B*B'))^(-(hua_num-1)/2))*((det(S*(XE^(-1))))^(-1/2))*((det(ZPC{1,BP_pre{1,i}{9,j}}))^((detac-d-1)/2))*(detac^(detac/2)); 
w2=(det(BP_pre{1,i}{6,j}))^((BP_pre{1,i}{5,j}-d-1)/2)/(det(V)^((v-d-1)/2)); 
w3=(gamma((v-d-1)/2)*gamma((v-d-2)/2))/(gamma(((BP_pre{1,i}{5,j}-d-1)/2))*gamma(((BP_pre{1,i}{5,j}-d-2)/2))*(pi^(d*(d-1)/4)*gamma(detac/2)*gamma((detac-1)/2)));
                     
        bL=w1*w2*w3;
      
        bG= (gamma(BP_pre{1,i}{7,j}+hua_num)*(BP_pre{1,i}{8,j})^(BP_pre{1,i}{7,j}))/(gamma(BP_pre{1,i}{7,j})*(1+BP_pre{1,i}{8,j})^(BP_pre{1,i}{7,j}+hua_num)*factorial(hua_num)+eps);                               %GAMMA����

                 
                    
                       
   
        
                                
  bGG=bQ*bL*bG;
    
       BP_update{1,i}{1,aa}=1;
       BP_update{1,i}{2,aa}= yita(i,a)*bGG;
       BP_update{1,i}{3,aa}= BP_pre{1,i}{3,j}+K*e;
       BP_update{1,i}{4,aa}= BP_pre{1,i}{4,j}-K*H*BP_pre{1,i}{4,j};
       BP_update{1,i}{5,aa}= v;
       BP_update{1,i}{6,aa}= V;
       BP_update{1,i}{7,aa}= BP_pre{1,i}{7,j}+size( WP{1,a},2);
       BP_update{1,i}{8,aa}= BP_pre{1,i}{8,j}+1;
       BP_update{1,i}{9,aa}=BP_pre{1,i}{9,j};
        BP_update{1,i}{10,aa}=yita(i,a)*bGG;
else 

       BP_update{1,i}{1,aa}=BP_pre{1,i}{1,j};
       BP_update{1,i}{2,aa}= BP_pre{1,i}{2,j}*(1-1)*yita(i,a);
       BP_update{1,i}{3,aa}= BP_pre{1,i}{3,j};
       BP_update{1,i}{4,aa}= BP_pre{1,i}{4,j};
       BP_update{1,i}{5,aa}= BP_pre{1,i}{5,j};
       BP_update{1,i}{6,aa}= BP_pre{1,i}{6,j};
       BP_update{1,i}{7,aa}= BP_pre{1,i}{7,j};
       BP_update{1,i}{8,aa}= BP_pre{1,i}{8,j};
       BP_update{1,i}{9,aa}= BP_pre{1,i}{9,j};
       BP_update{1,i}{10,aa}= BP_pre{1,i}{10,j};





end
 
 aa=aa+1;
 
          end
 
 
      end
     
            
                            ww=zeros(1,2);
                            NUM=size([ BP_update{1,i}{2,:}],2);
                             for nn=1:NUM
            ww(1, BP_update{1,i}{9,nn})=ww(1,BP_update{1,i}{9,nn})+BP_update{1,i}{2,nn};
            end
                            
                             
           sumww=sum(ww);  
           ww=ww/sumww;
          for nn=1:NUM
            BP_update{1,i}{10,nn}=ww(1,BP_update{1,i}{9,nn});
            end
            
           
      
      
      
      
      
    



BP_update{2,i}{1,1}= 0;
  BP_update{2,i}{2,1}= yita(i,a)*BP_pre{2,i}{2,1}; 
  yita1{1,k}=yita;
  BP_update10{1,k}=BP_update;
  

 CC=sum([BP_update{1,i}{2,:}])+BP_update{2,i}{2,1};

 for c=1:size(BP_update{1,i},2)
 BP_update{1,i}{2,c}=BP_update{1,i}{2,c}/CC;
 end
  BP_update{2,i}{2,1}=BP_update{2,i}{2,1}/CC;
 end
   BP_update11{1,k}=BP_update;
%  

 BP_update1={};
  BP_update2={};
  BP_update5=BP_update;
  ss=1;
 for i=1:size(BP_update,2)
 TT(1,i) =sum([BP_update{1,i}{2,:}]);
 end
[w1,index]=sort(TT,'descend');

      for i=1:size(BP_update,2) 
         if TT(1,i)>=5.83155774653450e-32
           BP_update1{1,ss}=BP_update{1,i}; 
     BP_update1{2,ss}=BP_update{2,i};
     ss=ss+1;
         end
          
      end
     
    
     for i=1:size(BP_update1,2)
     
         
         [w1,index1]=sort([BP_update1{1,i}{2,:}],'descend');
         for s=1:1
         BP_update2{1,i}{1,s}=BP_update1{1,i}{1,index1(1,s)};
         BP_update2{1,i}{2,s}=BP_update1{1,i}{2,index1(1,s)};
          BP_update2{1,i}{3,s}=BP_update1{1,i}{3,index1(1,s)};
           BP_update2{1,i}{4,s}=BP_update1{1,i}{4,index1(1,s)};
            BP_update2{1,i}{5,s}=BP_update1{1,i}{5,index1(1,s)};
             BP_update2{1,i}{6,s}=BP_update1{1,i}{6,index1(1,s)};
              BP_update2{1,i}{7,s}=BP_update1{1,i}{7,index1(1,s)};
               BP_update2{1,i}{8,s}=BP_update1{1,i}{8,index1(1,s)};
                BP_update2{1,i}{9,s}=BP_update1{1,i}{9,index1(1,s)};
                 BP_update2{1,i}{10,s}=BP_update1{1,i}{10,index1(1,s)};
         
         end
         
      
 
     BP_update2{2,i}=BP_update1{2,i};
     end
      
    
     BP_update=BP_update2;
     

 
    
     
     
     
     
      XK{1,k}={};
      
     
    %State extract
    u=0;
     for i=1:size(BP_update2,2)
         if BP_update2{1,i}{2,1}>7.48865009907737e-12
             u=u+1;
         XK{1,k}{1,u}=BP_update2{1,i}{2,1};
     XK{1,k}{2,u}=BP_update2{1,i}{3,1};
     XK{1,k}{3,u}=BP_update2{1,i}{6,1}/(BP_update2{1,i}{5,1}-2*d-2);
     XK{1,k}{4,u}=BP_update2{1,i}{7,1}/BP_update2{1,i}{8,1};
        XK{1,k}{5,u}=BP_update2{1,i}{9,1};
         XK{1,k}{6,u}=BP_update2{1,i}{10,1};
    
     end
      end
      XK{2,k}=vv;
      
     
% %      
% %     

                                                                        % ospa     
%  
            
                             
                                    if (k<TS || k>TE) &&( k<TS1 || k>TE1)                                          
                                    YR{1,k}=[x1(:,k),x2(:,k),x3(:,k)];
                                    end
                                   if (k>=TS && k<TE+1)
                                  YR{1,k}=[x1(:,k),x2(:,k),x3(:,k),x4(:,k)];
                                 end
                                if (k>=TS1 && k<TE1+1)
                                  YR{1,k}=[x1(:,k),x2(:,k),x3(:,k),x5(:,k)];
                                end
                           
                                 if size(XK{1,k},2)~=0
                              X{1,k}=[XK{1,k}{2,:}];
                                 else
                                     X{1,k}=[];
                                 end
                           
                         
                               if (k<TS || k>TE) &&( k<TS1 || k>TE1)                                               
                                    YYR{1,k}=[X1,X2,X3];
                                    end
                                   if (k>=TS && k<TE+1)
                                  YYR{1,k}=[X1,X2,X3,X4];
                                 end
                                if (k>=TS1 && k<TE1+1)
                                  YYR{1,k}=[X1,X2,X3,X5];
                                end
                            
                             if size(XK{1,k},2)~=0
                              XX{1,k}=[XK{1,k}{3,:}];
                                 else
                                     XX{1,k}=[];
                                 end

                              
                               
                               if (k<TS || k>TE) &&( k<TS1 || k>TE1)                                   
                                    Yr{1,k}=[r1,r2,r3];
                                    end
                                   if (k>=TS && k<TE+1)
                                  Yr{1,k}=[r1,r2,r3,r4];
                                 end
                                if (k>=TS1 && k<TE1+1)
                                  Yr{1,k}=[r1,r2,r3,r5];
                                end
                             
                             if size(XK{1,k},2)~=0
                              rr{1,k}=[XK{1,k}{4,:}];
                             else
                                  rr{1,k}=[];
                             end
                                   
                              
                              
                               [sumxxm(1,k)]=ospa_dist( YR{1,k}, X{1,k},10,pp);
                              [sumXXm(1,k)]=ospa_dist( YYR{1,k}, XX{1,k},0.35*10^4,pp);
                              [sumrrm(1,k)]=ospa_dist( Yr{1,k}, rr{1,k},cc3,pp);
targetnumm(1,k)=size(YR{1,k},2);
                             
 
 

end
XKMC{1,moto}=XK;







     




% 

%    
  
       
 x_ospam=x_ospam+sumxxm;
X_ospam=X_ospam+sumXXm;  
r_ospam=r_ospam+sumrrm;

end
  x_ospam=x_ospam/motob;
    X_ospam=X_ospam/(motob*10^4);
     r_ospam=r_ospam/motob;

    
 
 

figure(1);
 hold on;
axis([0 time 0 15]);
 plot(1:time,x_ospam(1,:),'-b');
   

figure(2);
 hold on;
axis([0 time 0 0.8]);
 plot(1:time,X_ospam(1,:),'-bo');
  
figure(3);
 hold on;
axis([0 time 0 5]);
 plot(1:time,r_ospam(1,:),'-bo');
     
