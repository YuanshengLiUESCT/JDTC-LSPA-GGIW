
function WW=partition(ZK,BP_pre)
H = [1 0 0 0;
     0 0 1 0];
 
% zc1=[];
% zc2=[];
% zc3=[];
zc=cell(1,size(BP_pre,2));

index=[];%�洢����Ŀ���index
    for i=1:size(ZK,2)
        if size(BP_pre,2)==4
        for  j=1:size(BP_pre,2)
        
        if sqrt([ZK(:,i)-H*BP_pre{:,j}]'*[ZK(:,i)-H*BP_pre{:,j}])<110*sqrt(2)
            zc{1,j}=[zc{1,j},ZK(:,i)];
            
            index=[index,i];
            ZK(:,i)=nan;
        end
            
        end
    
        else
        
         for  j=1:size(BP_pre,2)
        
        if norm([ZK(:,i)-H*BP_pre{:,j}])<80*sqrt(2)
            zc{1,j}=[zc{1,j},ZK(:,i)];
            
            index=[index,i];
            ZK(:,i)=nan;
        end
            
         end
    end
        
        
        
        
        
        
        
        
        
        
    end
ZK(:,index)=[];

for i=1:size(ZK,2)
    zc=[zc, ZK(:,i)];
end

WW=zc;





%     if sqrt([ZK(:,i)-H*x1]'*[ZK(:,i)-H*x1])<100
%     zc1=[zc1,ZK(:,i)];
%     index=[index,i];
%     
%     else if sqrt([ZK(:,i)-H*x2]'*[ZK(:,i)-H*x2])<100
%               zc2=[zc2,ZK(:,i)];
%               index=[index,i];
%             
%         else if sqrt([ZK(:,i)-H*x3]'*[ZK(:,i)-H*x3])<100
%                 zc3=[zc3,ZK(:,i)];
%                 index=[index,i];
%           
%             end
%         end
